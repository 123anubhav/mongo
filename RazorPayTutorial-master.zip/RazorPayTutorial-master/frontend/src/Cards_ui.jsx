import { Button, Image, Text, VStack ,Input,
    FormControl,
    FormLabel,
    FormErrorMessage,
    FormHelperText,
  } from '@chakra-ui/react'
  import { useState } from 'react'

const Card = ({ amount, img, checkoutHandler }) => {
    const [input, setInput] = useState('')

    const handleInputChange = (e) => setInput(e.target.value)
  
    const isError = input === ''
    return (
        <VStack>
            {/* <Image src={img} boxSize={"64"} objectFit="cover" /> */}
            <FormControl isInvalid={isError}>
        
            <FormControl isInvalid={isError}>

      {/* <FormLabel>Name</FormLabel>
      <Input
        type='text'
        value={input}
        onChange={handleInputChange}
      />
      {!isError ? (
        <FormHelperText>
          Enter the Name
        </FormHelperText>
      ) : (
        <FormErrorMessage>Name is required.</FormErrorMessage>
      )}
    </FormControl>

    <FormControl isInvalid={isError}> */}

<FormLabel>E-mail</FormLabel>
<Input
  type='email'
  value={input}
  onChange={handleInputChange}
/>
{!isError ? (
  <FormHelperText>
    Enter the email you'd like to receive the newsletter on.
  </FormHelperText>


) : (
  <FormErrorMessage>Email is required.</FormErrorMessage>
)}
</FormControl>


{/* <FormControl isInvalid={isError}>


<FormLabel>Contact</FormLabel>
<Input
  type='number'
  value={input}
  onChange={handleInputChange}
/>
{!isError ? (
  <FormHelperText>
    Enter the Conatct you'd like to receive the newsletter on.
  </FormHelperText>
) : (
  <FormErrorMessage>Contact is required.</FormErrorMessage>
)}
</FormControl>
 */}
<Text>₹{amount}</Text>
            <Button onClick={() => checkoutHandler(amount)}>Buy Now</Button>
            
    </FormControl>
            {/* <Text>₹{amount}</Text>
            <Button onClick={() => checkoutHandler(amount)}>Buy Now</Button>
             */}
        </VStack>
    )
}
export default Card
