import { useState } from "react";
import ReactDOM from 'react-dom/client';
import { Button, Image, Text, VStack } from '@chakra-ui/react'


// function MyForm() {
//   const [name, setName] = useState("");

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     alert(`The name you entered was: ${name}`);
//   }
  const Card = ({ amount, img, checkoutHandler }) => {
  return (
    function MyForm() {
        const [name, setName] = useState("");
      
        const handleSubmit = (event) => {
          event.preventDefault();
          alert(`The name you entered was: ${name}`);
        }
      
    <form onSubmit={handleSubmit}>
      <label>Enter your name:
        <input 
          type="text" 
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </label>
      <Button onClick={() => checkoutHandler(amount)}>Buy Now</Button>
    </form>
   } ) 
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<MyForm />);
export default Card

